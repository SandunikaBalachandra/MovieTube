package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;

import java.util.ArrayList;

public class EditSelectedMovie extends AppCompatActivity {

    ArrayList<String> allmoviedatalist = new ArrayList<>();
    Database data = new Database(this);
    String[] values;
    Button saveButton;
    RatingBar starBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_selected_movie);

        EditText name = findViewById(R.id.tb1);
        EditText year = findViewById(R.id.tb2);
        EditText director = findViewById(R.id.tb3);
        EditText actors = findViewById(R.id.tb4);
        EditText review = findViewById(R.id.tb6);
        EditText favorite = findViewById(R.id.tb7);
        starBar = findViewById(R.id.starBar);
        saveButton = findViewById(R.id.buttons);

        //to get string from previous activity
        String newString;
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                newString= null;
            } else {
                newString= extras.getString("Movie_Name");
            }
        } else {
            newString= (String) savedInstanceState.getSerializable("Movie_Name");
        }
        System.out.println(newString + "came");

        allmoviedatalist=data.getAll();

        for(int m=0;m<allmoviedatalist.size();m++){
            if(allmoviedatalist.get(m).contains(newString)){
                String data1 = allmoviedatalist.get(m);
                System.out.println(data1);
                values = data1.split("-");

                for(String n :values){
                    System.out.println(n);
                }

            }
        }

        name.setText(values[0]);
        name.setEnabled(false);
        year.setText(values[1]);
        director.setText(values[2]);
        actors.setText(values[3]);
        String rateNum = values[4];
        starBar.setRating(Float.parseFloat(rateNum));

        System.out.println(rateNum);

        review.setText(values[5]);
        if(values[6].equals("yes")){
            favorite.setText("Favourite");
        }else{
            favorite.setText("Not Favourite");
        }

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("button pressed");

                System.out.println("progesss: " + starBar.getProgress());
                int yearint = Integer.parseInt(year.getText().toString());
                int ratingint = starBar.getProgress();

                String fstatus;
                //get favourite status
                if(favorite.getText().toString().toLowerCase().equals("favourite")){
                    fstatus = "yes";
                }else{
                    fstatus = "no";
                }
                //update database
                data.updateData(values[0],yearint,director.getText().toString().toLowerCase(),actors.getText().toString().toLowerCase(),ratingint,review.getText().toString().toLowerCase(),"yes");
                System.out.println("fstatus : "+fstatus);
            }
        });

    }

}

//references
//https://www.youtube.com/watch?v=GQsibTm-aw4