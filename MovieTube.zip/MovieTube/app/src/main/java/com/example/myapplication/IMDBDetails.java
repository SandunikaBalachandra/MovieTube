package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class IMDBDetails extends AppCompatActivity {

    ArrayList<String> movieDetails = new ArrayList<>();
    ArrayList<String> images = new ArrayList<>();
    Database data = new Database(this);
    String[] values;
    String nameOfMovie;
    TextView rateTxt,imgTxt,idTxt,fullTitleTxt;
    ImageView movieImg;
    URL imgurl;
    private static String key = "k_44wnxckl";
    String result="", rateResult="";
    String resultId="";
    String getId="";
    String getRate="";
    String getImgLink="";
    Bitmap imgBitmap;

    String api = "https://imdb-api.com/API/SearchTitle/k_44wnxckl/";
    String apiRate = "https://imdb-api.com/en/API/Ratings/k_44wnxckl/";
    String urlRate= "https://imdb-api.com/en/API/Ratings/k_44wnxckl/"+getId;
    String url = "https://imdb-api.com/API/SearchTitle/k_44wnxckl/"+nameOfMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_i_m_d_b_details);

         movieDetails =data.getAll();
        rateTxt=findViewById(R.id.rateTxt);
        idTxt=findViewById(R.id.idTxt);
        imgTxt=findViewById(R.id.imgTxt);
        movieImg=findViewById(R.id.movieImg);
        fullTitleTxt=findViewById(R.id.title_imdb);


        String newString;
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                newString= null;
            } else {
                newString= extras.getString("movieName");
            }
        } else {
            newString= (String) savedInstanceState.getSerializable("movieName");
        }

        //checking if last activity contains list name and getting details for it

        for(int m = 0; m< movieDetails.size(); m++){
            if(movieDetails.get(m).contains(newString)){
                String data1 = movieDetails.get(m);
                System.out.println(data1);
                values = data1.split("-");
                //just to check
                for(String n :values){
                    System.out.println(n);
                }

            }
        }

        //setting values
        fullTitleTxt.setText(values[0]);
        nameOfMovie= (values[0]);

        url = api+fullTitleTxt.getText().toString();
        getData();
        urlRate = apiRate+getId;

        setMovieImg();
        getRateData();


    }


    public class DownloadJSON extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            URL url,rateUrl;
            HttpURLConnection httpURLConnection,httpURLConnectionRate;
            InputStream inputStream,inputStreamRate;
            InputStreamReader inputStreamReader,inputStreamReaderRate;


            try {
                url=new URL(strings[0]);

                httpURLConnection= (HttpURLConnection) url.openConnection();
                inputStream= httpURLConnection.getInputStream();
                inputStreamReader=new InputStreamReader(inputStream);

                int data = inputStreamReader.read();

                while (data != -1){
                    resultId += (char)data;
                    data= inputStreamReader.read();
                }

                result=resultId;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (!getImgLink.equals("")){
                try {
                    imgurl = new URL(getImgLink);
                    System.out.println(getImgLink);

                    HttpURLConnection connection = (HttpURLConnection) imgurl.openConnection();
                    connection.setDoInput(true);
                    connection.connect();
                     InputStream input = new URL(images.get(0)).openStream();
                    imgBitmap = BitmapFactory.decodeStream(input);
                    movieImg.setImageBitmap(imgBitmap);



                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            if (!getId.equals("")){
                try {
                    rateUrl=new URL(urlRate);
                    httpURLConnectionRate= (HttpURLConnection) rateUrl.openConnection();
                    inputStreamRate= httpURLConnectionRate.getInputStream();
                    inputStreamReaderRate=new InputStreamReader(inputStreamRate);
                    int dataRate = inputStreamReaderRate.read();

                    while (dataRate != -1){
                        rateResult += (char)dataRate;
                        dataRate= inputStreamReaderRate.read();
                    }
                    result=rateResult;

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }


            return result;
        }

    }

    public void getData(){

        DownloadJSON downloadJSON=new DownloadJSON();
        String getTitle="";

        try {
            result = downloadJSON.execute(url).get();
            JSONObject jsonObject=new JSONObject(result);
            JSONArray jsonArray=jsonObject.getJSONArray("results");

            int count =0;
            while (count<jsonArray.length())
            {
                JSONObject JO=jsonArray.getJSONObject(count);
                count++;
                getTitle=JO.getString("title");
                getId=JO.getString("id");
                getImgLink=JO.getString("image").toString();
                images.add(getImgLink);


            }
            fullTitleTxt.setText(getTitle);
            idTxt.setText(getId);
            imgTxt.setText(images.get(0));

            Log.i("JSON",result);
            Log.i("URL",url);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {

            Log.e("error", String.valueOf(e));
            e.printStackTrace();
        }


    }

    //set movie image
    public void setMovieImg(){
        movieImg.setImageBitmap(imgBitmap);
    }

    //get rating
    public void getRateData(){

        DownloadJSON downloadJSON=new DownloadJSON();


        String getRate="";

        try {
            rateResult = downloadJSON.execute(urlRate).get();
            System.out.println(urlRate);

            JSONObject jsonObject=new JSONObject(rateResult);

            getRate=jsonObject.getString("imDb");

            fullTitleTxt.setText(nameOfMovie);
            rateTxt.setText(getRate);


            Log.i("JSON",result);
            Log.i("URL",url);

        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            Log.e("error", String.valueOf(e));
            e.printStackTrace();
        }


    }

}
//references
//https://www.youtube.com/watch?v=TJQzlm5A3xQ