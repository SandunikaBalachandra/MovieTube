package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class IMDBRating extends AppCompatActivity implements AdapterView.OnItemClickListener{

    ListView listView;
    ArrayList<String> selectedMovieList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_i_m_d_b_rating);
        listView = findViewById(R.id.selected_movie_list);
        listView.setOnItemClickListener(this);
        Intent intent = getIntent();

        selectedMovieList = intent.getStringArrayListExtra("checkedMovieList");

        final ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1, selectedMovieList);
        listView.setAdapter(adapter);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long l) {

        //create intent and pass selected movie list
        Intent intent1 = new Intent(this, IMDBDetails.class);
        String strName = selectedMovieList.get(i);
        intent1.putExtra("movieName", strName);
        startActivity(intent1);

    }
}