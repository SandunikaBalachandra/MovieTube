package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class RegisterMovieActivity extends AppCompatActivity {
    Button register;
    EditText mname,myear,mdirector,mactor,mrating,mreview;
    Database mdata;
    Integer myint,mrint;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_movie);

        register = findViewById(R.id.sbtn);
        mname = findViewById(R.id.TE1);
        myear = findViewById(R.id.TE2);
        mdirector = findViewById(R.id.TE3);
        mactor = findViewById(R.id.TE4);
        mrating = findViewById(R.id.TE5);
        mreview = findViewById(R.id.TE6);

        mdata = new Database(this);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myint = Integer.parseInt(myear.getText().toString());
                mrint = Integer.parseInt(mrating.getText().toString());

                //Check year validations
                if ((myint < 1895) || (myint > 2021)) {

                    AlertDialog alertDialog = new AlertDialog.Builder(RegisterMovieActivity.this).create();
                    alertDialog.setTitle("Alert");
                    alertDialog.setMessage("Please Enter Valid Year!! \n It should be between 1895 - 2021");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }

                //check rating validations
                if ((0 > mrint) || (mrint > 10)) {

                    AlertDialog alertDialog = new AlertDialog.Builder(RegisterMovieActivity.this).create();
                    alertDialog.setTitle("Alert");
                    alertDialog.setMessage("Please Enter Valid Rating!! \n It should be between 1 - 10");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }

                if((myint > 1895) && (1 < mrint && mrint < 10)){
                    System.out.println("All validated!");
                    save();
                }
                load();

            }
        });

    }

    public void save(){
        int myearint = Integer.parseInt(myear.getText().toString());
        int mratingint = Integer.parseInt(mrating.getText().toString());
        mdata.insertData(mname.getText().toString().toLowerCase(),myearint,mdirector.getText().toString().toLowerCase(),mactor.getText().toString().toLowerCase(),mratingint,mreview.getText().toString().toLowerCase());

    }
    public void load(){
        mdata.getAll();
    }




}
