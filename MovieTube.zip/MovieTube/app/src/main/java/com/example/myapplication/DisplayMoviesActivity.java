package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;

public class DisplayMoviesActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> moviedatalist = new ArrayList<>();
    ArrayList<String> allmoviedatalist = new ArrayList<>();
    Database data = new Database(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_movies);

        Button btnf = findViewById(R.id.btnf);
        listView = findViewById(R.id.editmovielist);

        moviedatalist = data.getAllNames();
        allmoviedatalist=data.getAll();
        System.out.println(allmoviedatalist);

        Collections.sort(moviedatalist);


        for (String i : moviedatalist) {
            System.out.println(i);
        }

        final ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_multiple_choice, moviedatalist);
        //set adapter to listview
        listView.setAdapter(adapter);

        btnf.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        saveFavorites();
                    }
                });

    }


    private void saveFavorites(){
        //get checked positions in listview
        SparseBooleanArray checked = listView.getCheckedItemPositions();

        for (int i = 0; i < listView.getAdapter().getCount(); i++) {
            if (checked.get(i)) {
                if (checked.get(i)==true){

                    for(int m=0;m<allmoviedatalist.size();m++){
                        if(allmoviedatalist.get(m).contains(moviedatalist.get(i))){
                            System.out.println("have");
                            String data1 = allmoviedatalist.get(m);
                            System.out.println(data1);
                            String[] values = data1.split("-");
                            for(String n :values){
                                System.out.println(n);
                            }
                            int year = Integer.parseInt(values[1]);
                            int rating = Integer.parseInt(values[4]);

                            //update database
                            data.updateData(values[0],year,values[2],values[3],rating,values[5],"yes");


                        }
                    }
                }
            }
        }
    }
}