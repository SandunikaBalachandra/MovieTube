package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class EditMoviesActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView listView;
    Database data = new Database(this);
    ArrayList<String> moviedatalist = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_movies);


        listView = findViewById(R.id.editmovielist);
        listView.setOnItemClickListener(this);

        //get all names to arraylist
        moviedatalist = data.getAllNames();

        ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1, moviedatalist);listView.setAdapter(adapter);


    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        System.out.println("clicked "+moviedatalist.get(i));

        Log.i("ListView", "You clicked Item: ");
        //create intent and pass movie list selected
        Intent intent = new Intent(this, EditSelectedMovie.class);
        String strName = moviedatalist.get(i);
        intent.putExtra("Movie_Name", strName);
        startActivity(intent);
    }

}