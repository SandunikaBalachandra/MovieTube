package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Database data = new Database(this);
    ArrayList<String> names;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void goToRegisterMoviesActivity(View view) {
        Intent i = new Intent(this,RegisterMovieActivity.class);
        startActivity(i);

    }

    public void goToDisplayMoviesActivity(View view) {
        Intent i = new Intent(this,DisplayMoviesActivity.class);
        startActivity(i);

    }

    public void goToFavoritesActivity(View view) {
        Intent i = new Intent(this,FavoritesActivity.class);
        startActivity(i);

    }

    public void goToEditMoviesActivity(View view) {
        Intent i = new Intent(this,EditMoviesActivity.class);
        startActivity(i);

    }

    public void goToSearchActivity(View view) {
        Intent i = new Intent(this,SearchActivity.class);
        startActivity(i);

    }

    public void goToRatingsActivity(View view) {
        Intent i = new Intent(this,RatingsActivity.class);
        startActivity(i);

    }


    public void deleteDatabase(View view) {
        //getting names from the db
        names = data.getAllNames();
        System.out.println(names);

        //deleting the data one by one
        for (int i = 0; i <names.size() ; i++) {
            data.deleteData(names.get(i));

        }
    }
}