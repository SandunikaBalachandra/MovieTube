package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    String tbinput;
    ArrayList<String> moviedatalist = new ArrayList<>();
    ArrayList<String> showlist = new ArrayList<>();
    int count = 0;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        listView = findViewById(R.id.editmovielist);
        EditText searchtext = (EditText) findViewById(R.id.searchbar);
        Button sbtn = findViewById(R.id.ssbtn);

        Database data = new Database(this);

        moviedatalist = data.getAllSearch();

        for (String i : moviedatalist) {
           System.out.println(i);
        }

        sbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(count>=1){
                            showlist.clear();
                        }
                        //get searched text
                        tbinput = searchtext.getText().toString().toLowerCase();
                        //get movies contains searched word in details
                        for(int i =0;i<moviedatalist.size();i++){
                                if(moviedatalist.get(i).contains(tbinput)){
                                        showlist.add(moviedatalist.get(i));
                                }
                        }
                        showlist();
                        count++;
                    }
                });

    }

    private void showlist() {
        final ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1, showlist);listView.setAdapter(adapter);
    }
}

//references
//https://www.youtube.com/watch?v=QY-O49a_Ags