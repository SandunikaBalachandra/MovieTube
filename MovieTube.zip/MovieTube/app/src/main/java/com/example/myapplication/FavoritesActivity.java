package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class FavoritesActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> allmoviedatalist = new ArrayList<>();
    ArrayList<String> favallmoviedatalist = new ArrayList<>();
    ArrayList<String> favmoviedatalist = new ArrayList<>();
    Database data = new Database(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        Button savebtn = findViewById(R.id.btn);
        listView = findViewById(R.id.favoritelist);

        allmoviedatalist=data.getAll();



        System.out.println("allmoviedatalist : "+allmoviedatalist);
        for(int m =0;m<allmoviedatalist.size();m++) {
            String data1 = allmoviedatalist.get(m);
            String[] values = data1.split("-");
            if(values[6].equals("yes")){
                favmoviedatalist.add(values[0]);
                favallmoviedatalist.add(data1);
            }

        }
        System.out.println("favmoviedatalist : "+favmoviedatalist);
        final ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_multiple_choice, favmoviedatalist);
        listView.setAdapter(adapter);

        for (int x=0 ; x<=favmoviedatalist.size(); x++){
            listView.setItemChecked(x,true);

        }

        savebtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        changefavorites();
                    }

                });

    }

    private void changefavorites() {
        //get checked item positions
        SparseBooleanArray checked = listView.getCheckedItemPositions();

        System.out.println(checked);
        for (int x = 0; x <= favallmoviedatalist.size(); x++) {
            if (!(listView.isItemChecked(x))){
                System.out.println("unchecked" +favallmoviedatalist.get(x));
                String data1 = favallmoviedatalist.get(x);
                System.out.println(data1);
                String[] values = data1.split("-");
                for (String n : values) {
                    System.out.println(n);
                }
                int year = Integer.parseInt(values[1]);
                int rating = Integer.parseInt(values[4]);

                //update database
                data.updateData(values[0], year, values[2], values[3], rating, values[5], "no");

            }

        }


    }
}