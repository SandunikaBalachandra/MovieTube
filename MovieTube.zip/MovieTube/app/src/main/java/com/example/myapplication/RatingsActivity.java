package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;

public class RatingsActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<String> moviedatalist = new ArrayList<>();
    ArrayList<String> allmoviedatalist = new ArrayList<>();
    ArrayList<String> checkedmovielist = new ArrayList<>();
    Database data = new Database(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ratings);

        Button find = findViewById(R.id.find);
        listView = findViewById(R.id.rating_list);

        moviedatalist = data.getAllNames();
        allmoviedatalist=data.getAll();
        System.out.println(allmoviedatalist);

        Collections.sort(moviedatalist);

        for (String i : moviedatalist) {
            System.out.println(i);
        }


        final ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_single_choice, moviedatalist);
        listView.setAdapter(adapter);

        find.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        findRating();
                    }
                });

    }

    private void findRating() {
        SparseBooleanArray checked = listView.getCheckedItemPositions();
        for (int i = 0; i < listView.getAdapter().getCount(); i++) {
            if (checked.get(i)) {
                if (checked.get(i)==true){

                 for(int m=0;m<allmoviedatalist.size();m++){
                        if(allmoviedatalist.get(m).contains(moviedatalist.get(i))){

                            System.out.println("clicked "+moviedatalist.get(i));
                            checkedmovielist.add(moviedatalist.get(i));
                        }
                    }
                }
            }
        }
        System.out.println(checkedmovielist);
        //create intent and pass checked movie list
        Intent intent = new Intent(this, IMDBRating.class);
        intent.putStringArrayListExtra("checkedMovieList", checkedmovielist);
        startActivity(intent);

    }

}