package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    static final private String DB_NAME = "MovieDatabase";
    static final private String DB_TABLE = "MovieListTable";
    static final private int DB_VER = 1;

    Context ctx;
    SQLiteDatabase mDb;

    public Database(Context ct){
        super(ct,DB_NAME,null,DB_VER);
        ctx =ct;
    }
//create table
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase){

        sqLiteDatabase.execSQL("create table "+DB_TABLE+" (_id integer primary key autoincrement,mname text,myear integer,mdirector text,mactors text,mrating integer,mreview text,favorite text);");
        Log.i("Database","table Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i ,int i1){
        sqLiteDatabase.execSQL("drop table if exists "+DB_TABLE);
        onCreate(sqLiteDatabase);


    }
//update data
    public Boolean updateData( String name ,int year, String director, String actors, int rating,String review, String favorites){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("mname", name);
        contentValues.put("myear", year);
        contentValues.put("mdirector", director);
        contentValues.put("mactors", actors);
        contentValues.put("mrating", rating);
        contentValues.put("mreview", review);
        contentValues.put("favorite", favorites);

        Cursor cursor = DB.rawQuery("select * from MovieListTable where mname = ?", new String[] {name});

        if(cursor.getCount()>=1){
            long result = DB.update("MovieListTable",contentValues, "mname=?", new String[] {name});

            if(result==-1){
                return false;
            }else{
                Toast.makeText(ctx,"Data saved Successfully",Toast.LENGTH_SHORT).show();
                return true;
            }
        }else{
            return false;
        }
    }
//insert Data
    public void insertData(String s1,int i1,String s2,String s3,int i2,String s4){
        mDb = getWritableDatabase();
        String s6 = "no";
        mDb.execSQL("insert into "+DB_TABLE+" (mname,myear,mdirector,mactors,mrating,mreview,favorite) values('"+s1+"',"+i1+",'"+s2+"','"+s3+"',"+i2+",'"+s4+"','"+s6+"')");
        Toast.makeText(ctx,"Data saved Successfully",Toast.LENGTH_SHORT).show();
    }
//get all data
    public ArrayList<String> getAll(){
        mDb = getReadableDatabase();
        Cursor cr = mDb.rawQuery("Select * from "+DB_TABLE,null);
        StringBuilder str = new StringBuilder();
        ArrayList<String> moviedata = new ArrayList<>();
        while (cr.moveToNext()){
            String s1 = cr.getString(1);
            int i1 = cr.getInt(2);
            String s2 = cr.getString(3);
            String s3 = cr.getString(4);
            int i2 = cr.getInt(5);
            String s4 = cr.getString(6);
            String s5 = cr.getString(7);
            String strrr = (s1+"-"+i1+"-"+s2+"-"+s3+"-"+i2+"-"+s4+"-"+s5);
            //str.append(s1+"-"+i1+"-"+s2+"-"+s3+"-"+i2+"-"+s4+"-"+s5+"\n");
            moviedata.add(String.valueOf(strrr));
        }
        Toast.makeText(ctx,str.toString(),Toast.LENGTH_SHORT).show();
        return moviedata;
    }

    //get all searched
    public ArrayList<String> getAllSearch(){
        mDb = getReadableDatabase();
        Cursor cr = mDb.rawQuery("Select * from "+DB_TABLE,null);
        StringBuilder str = new StringBuilder();
        ArrayList<String> moviedata = new ArrayList<>();
        while (cr.moveToNext()){
            String s1 = cr.getString(1);
            String s2 = cr.getString(3);
            String s3 = cr.getString(4);
            //str.append(s1+" "+s2+"-"+s3);
            String strr = s1+" "+s2+"-"+s3;
            moviedata.add(String.valueOf(strr).toLowerCase());
        }
        Toast.makeText(ctx,str.toString(),Toast.LENGTH_SHORT).show();
        return moviedata;
    }
//get all names
    public ArrayList<String> getAllNames(){
        mDb = getReadableDatabase();
        Cursor cr = mDb.rawQuery("Select * from "+DB_TABLE,null);
        StringBuilder str = new StringBuilder();
        ArrayList<String> moviedatan = new ArrayList<>();
        while (cr.moveToNext()){
            String s1 = cr.getString(1);
            //str.append(s1+"\n");
            moviedatan.add(String.valueOf(s1));
        }
        Toast.makeText(ctx,str.toString(),Toast.LENGTH_SHORT).show();
        System.out.println(moviedatan);
        return moviedatan;
    }

    //Delete data method
    public void deleteData(String mname){
        mDb = getWritableDatabase();
        mDb.delete(DB_TABLE, "mname = ?", new String[] {mname});
    }

}
